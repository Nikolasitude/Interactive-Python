from sys import argv
from .interact import interact

interact(argv[1])